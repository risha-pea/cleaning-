# Shared Cleaning Checklist

A simple, phone-friendly shared cleaning checklist app for couples or roommates. Both users can see tasks in real-time, check them off, and see who completed what.

## Features

✅ **Shared across devices** – When one person checks off a task, the other person sees it update automatically  
👤 **Know who did what** – See which person completed each task  
📊 **Progress tracking** – Visual progress bar shows completion percentage  
⏰ **Organized by frequency** – Daily, weekly, monthly, and quarterly tasks  
🔄 **Automatic sync** – Uses browser local storage for persistence  
🌙 **Dark mode support** – Automatically switches to dark theme based on system preference  
📱 **Mobile optimized** – Works perfectly on phones, tablets, and desktops  

## Task Categories

- **Daily** (6 tasks) – Things to do every day
- **Weekly** (18 tasks) – Deep cleans for each week
- **Monthly** (10 tasks) – Tasks that need monthly attention
- **Quarterly** (12 tasks) – Big tasks every 3 months

## How to Use

### Option 1: Use the Live Version
Simply open `shared-cleaning-checklist.html` in your browser on both devices. You can:
- Email the file to each other
- Host it on GitHub Pages (see instructions below)
- Use a file sharing service

### Option 2: Host on GitHub Pages (Recommended)

1. **Fork or clone this repository**
   ```bash
   git clone https://github.com/yourusername/shared-cleaning-checklist.git
   cd shared-cleaning-checklist
   ```

2. **Enable GitHub Pages**
   - Go to your repository settings
   - Scroll to "GitHub Pages"
   - Select `main` branch as the source
   - Your site will be live at `https://yourusername.github.io/shared-cleaning-checklist/`

3. **Share the link**
   - Give your partner the GitHub Pages URL
   - Both of you open it on your phones
   - Enter your names and start using it!

### Option 3: Run Locally
Just open the `shared-cleaning-checklist.html` file directly in your browser:
```bash
# On Mac
open shared-cleaning-checklist.html

# On Windows
start shared-cleaning-checklist.html

# Or just double-click the file
```

## How It Works

1. **Enter your name** at the top of the app (you can use "You" or your actual name)
2. **Tap any task** to check it off – it will show who completed it
3. **Use filters** to view all tasks, or just daily/weekly/monthly/quarterly
4. **Watch it sync** – Your partner's phone updates automatically every 3 seconds
5. **Reset tasks** – Use the buttons at the bottom to reset daily or weekly tasks when they're done

## Storage

The app uses **browser local storage** to save your checklist. This means:
- Your data persists even if you close the browser
- Both devices need to be on the same local network or use the same hosted version
- Data is stored only in your browser (no cloud required, no privacy concerns)

**Note:** If you use different browsers or devices, you may need to set up sync:
- Desktop & Mobile: Open the same hosted URL on both devices
- Different accounts: Each person needs to open the same link to sync

## Customizing Tasks

To add or remove tasks:

1. Open `shared-cleaning-checklist.html` in a text editor
2. Find the `const tasks = [` section
3. Add or remove tasks following this format:
   ```javascript
   {
     category: "Daily",
     title: "Task name",
     details: "Description of what to do"
   }
   ```
4. Save the file

## Troubleshooting

**Tasks not syncing between devices?**
- Make sure you're both opening the same URL
- Both browsers must have local storage enabled
- Try refreshing the page on both devices

**Data disappeared after closing the browser?**
- Local storage should persist. If it doesn't, check if your browser is set to delete cookies/storage
- Try using a different browser

**Want to clear all data?**
- Open browser DevTools (F12 or Cmd+Option+I)
- Go to Application > Local Storage
- Find the entry for your domain and delete it

## Technical Details

- **Built with:** Vanilla HTML, CSS, and JavaScript (no dependencies)
- **Storage:** Browser localStorage API
- **Responsive:** Mobile-first design
- **Accessibility:** Semantic HTML, keyboard friendly
- **Performance:** Fast, lightweight (~15KB)

## Customization Ideas

Want to customize this further? Here are some ideas:

- Change the task list to match your home
- Modify colors in the CSS
- Add more task categories
- Integrate with a backend for cloud sync
- Add notifications/reminders
- Create a login system for privacy

## License

Feel free to use, modify, and share this project!

## Questions or Issues?

If you have feedback or want to improve this, feel free to:
- Open an issue on GitHub
- Submit a pull request
- Reach out with ideas

---

**Happy cleaning! 🧹** 

This app was designed to help couples and roommates see the full scope of household work and share the load fairly.
